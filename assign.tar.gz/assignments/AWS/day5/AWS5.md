Assignment 5 AWS


Task 1

Launch below infrastructure in your aws account using ansible's aws cloud modules

#Playbook link

https://github.com/tarungoel1995/assignments/blob/master/AWS/day5/test.yml

#playbook output

![Output](https://github.com/tarungoel1995/assignments/blob/master/AWS/day5/media/Northvirginiaplaybook.png)

create a key pair using ansible 

![keypair](https://github.com/tarungoel1995/assignments/blob/master/AWS/day5/media/keypair.png)

#IAM user creation

![IAM user](https://github.com/tarungoel1995/assignments/blob/master/AWS/day5/media/IAMuser.png)

create one security group that would allow you to ssh into the instance 

![Security Group](https://github.com/tarungoel1995/assignments/blob/master/AWS/day5/media/securitygruoup.png)


using the key that you created, launch an instance in default vpc of N.virginia region with tags of your choice 

![instance Launch](https://github.com/tarungoel1995/assignments/blob/master/AWS/day5/media/N.verginiainstance.png)

