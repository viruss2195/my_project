Contents of Puppet.md
- What is Puppet?
- How Puppet works
- Components of Puppet
- Complete procedure to setup a master slave connection (Applicable for centos 7)
- Example to install a package using manifests
- Example to install a package using Puppet modules
- Example to install a service and configure using custom module
