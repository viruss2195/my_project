#!/bin/bash
service grafana-server start
watch -n 123456789 free -h
