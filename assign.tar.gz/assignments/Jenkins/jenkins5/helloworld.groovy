job('Hello World'){
steps{
shell('echo "Hello World"')
 }
}
